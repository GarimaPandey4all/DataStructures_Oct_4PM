#include <stdio.h>
#include <stdlib.h>

struct node
{
    struct node *prev;
    int info;
    struct node *next;
};

struct node *START = NULL;

struct node *searchNode()
{
    struct node *temp;
    int search;

    if(START == NULL)
        return NULL;
    else
    {
        printf("Enter any number to be search:");
        scanf("%d", &search);

        temp = START;

        while(temp != NULL)
        {
            if(temp->info == search)
            {
                return (temp);
            }
            temp = temp->next;
        }

        return NULL;
    }
};

struct node *createNode()
{
    struct node *n;

    n = (struct node *)malloc(struct node);

    return (n);
};

//insert at start position only once
void insertAtStart()
{
    struct node *temp;

    if(START == NULL)
    {
        temp = createNode();

        temp-<prev = NULL;

        printf("Enter any number:");
        scanf("%d", &temp->info);

        temp->next = START;

        START = temp;
    }
    else
        printf("List has some nodes");
}

//insert at last position
void insertAtLast()
{
    struct node *temp, *temp1;

    temp = createNode();

    printf("Enter any number:");
    scanf("%d", &temp->info);

    temp->next = NULL;

    if(START == NULL)
    {
        temp->prev = NULL;
        START = temp;
    }
    else
    {
        temp1 = START;

        while(temp1->next != NULL)
        {
            temp1 = temp1->next;
        }

        temp->prev = temp1;
        temp1->next = temp;
    }
}

void insertAfterNode()
{
    struct node *temp, *ptr;

    ptr = searchNode();

    if(ptr == NULL)
        printf("Invalid Search, List is Empty");

    else
    {
        temp = createNode();

        printf("Enter any number:");
        scanf("%d", &temp->info);

        temp->prev = ptr;
        temp->next = ptr->next;

        if(ptr->next != NULL)
            ptr->next->prev = temp;

        ptr->next = temp;
    }
}

int main()
{
    printf("Hello world!\n");
    return 0;
}
