#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[10], i, n, search;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter %d elements:\n", n);
    for(i = 0; i < n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("Values in an Array are:\n");
    for(i = 0; i < n; i++)
    {
        printf("%d  ", array[i]);
    }

    printf("\nEnter any value to be search:");
    scanf("%d", &search);

    for(i = 0; i< n; i++)
    {
        if(search == array[i])
        {
            printf("%d value found at %d.", search, i + 1);
            exit(0);
        }
    }

    if(i == n) // n = 6, i = 6
    {
        printf("%d value is not found", search);
    }

    return 0;
}
