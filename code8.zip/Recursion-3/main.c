#include <stdio.h>
#include <stdlib.h>

// 4 : 0 1 1 2

int fib(int n)
{
    if(n == 0)
        return 0;
    if(n == 1 || n == 2)
        return 1;
    else
        return (fib(n - 1) + fib(n - 2));
}

int main()
{
    int n;

    printf("Enter any number:");
    scanf("%d", &n);

    printf("Fibonacci series is:\n");
    for(int i = 0; i < n; i++)
    {
        printf("%d  ", fib(i)); // 0 1 1 2 3
    }

    return 0;
}
