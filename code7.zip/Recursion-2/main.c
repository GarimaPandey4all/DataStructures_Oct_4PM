#include <stdio.h>
#include <stdlib.h>

//Factorial Number

int factorial(int n) // n = 3
{
    int result;

    if(n == 1)
        return n;

    result = n * factorial(n - 1); //result = 6; // 3 * 2 = 6, 2 * 1 = 2, 1

    return result; // recursive call
}

int main()
{
    int fact = 0;
    int n;

    printf("Enter any number:");
    scanf("%d", &n);

    fact = factorial(n); // fact = 6
    printf("Factorial Number is: %d", fact);

    return 0;
}
