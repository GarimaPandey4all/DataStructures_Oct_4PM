#include <stdio.h>
#include <stdlib.h>

//Sum of n Natural Numbers

int func(int a) // a = 3
{
    int sum;

    if(a == 1) // base condition = stop condition
        return a;

    //Processing Logic
    sum = a + func(a - 1); // recursive call // func(a - 1) --> small logic

    return sum;
}

int main()
{
    int x;
    x = func(3); // 1 + 2 + 3 = 6
    printf("Sum of Natural Number is: %d", x);

    return 0;
}
