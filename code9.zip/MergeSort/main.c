#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[10], temp[10], i, j, k, n, size, l1, h1, l2, h2;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter values of a list:\n");
    for(i = 0; i < n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("Values in a list are:\n");
    for(i = 0; i < n; i++)
    {
        printf("%d\t", array[i]);
    }

    //Logic for Merge Sort

    /*   0   1   2   3   4  5    6   7   8   9  10
        11, 66, 88, 33, 66, 77, 99, 88, 22, 44, 55



    */

    for(size = 1; size < n; size = size * 2) //n = 11, size = 1
    {
        l1 = 0; // 0
        k = 0; // index for temp array

        while(l1 + size < n) // n = 11, 0 + 1 = 1 < 11
        {
            h1 = l1 + size - 1; // 0
            l2 = h1 + 1; // 1
            h2 = l2 + size - 1; //

            //h2 exceeds the limit of array
            if(h2 >= n)
                h2 = n - 1;

            //Merge Two pairs

            i = l1;
            j = l2;

            while(i <= h1 && j <= h2)
            {
                if(array[i] <= array[j])
                    temp[k++] = array[i++];
                else
                    temp[k++] = array[j++];
            }

            while(i <= h1)
                temp[k++] = array[i++];

            while(j <= h2)
                temp[k++] = array[j++];

            //Merge Completed

            l1 = h2 + 1;
        }

        //Any Pair Left
        for(i = l1; i < n; i++)
        {
            temp[k++] = array[i];
        }

        for(i = 0; i < n; i++)
            array[i] = temp[i];

        printf("\nSize of %d elememts are:", size);
        for(i = 0; i < n; i++)
            printf("%d  ", array[i]);
    }

    printf("\nSorted Array is:\n");
    for(i = 0; i < n; i++)
    {
        printf("%d  ", array[i]);
    }

    return 0;
}
