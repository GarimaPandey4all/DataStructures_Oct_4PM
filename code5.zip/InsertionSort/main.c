#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[10], i, j, n, temp;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter values in an array:\n");
    for(i = 0; i < n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("Values in an array:\n");
    for(i = 0; i < n; i++)
    {
        printf("%d  ", array[i]);
    }

    /*
        10, 3, 7, 5, 2
        ?, 10, 7, 5, 2
        3, 10, 7, 5, 2

    */

    for(i = 1; i < n; i++)
    {
        temp = array[i]; // 3
        j = i - 1; // 0

        while(j >= 0 && array[j] > temp) // 10 > 3
        {
            array[j + 1] = array[j];
            j = j - 1; // -1
        }
        array[j + 1] = temp; // 3
    }

    printf("\nSorted Array is:\n");
    for(i = 0; i < n; i++)
    {
        printf("%d  ", array[i]);
    }

    return 0;
}
