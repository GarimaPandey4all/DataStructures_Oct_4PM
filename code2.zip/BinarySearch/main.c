#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[10], i, n, first, last, middle, search;

    printf("Enter number of elements");
    scanf("%d", &n);

    printf("Enter values:\n");
    for(i = 0; i < n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("Values in an array are:\n");
    for(i = 0; i < n; i++)
    {
        printf("%d  ", array[i]);
    }

    printf("\nEnter any number to be search:");
    scanf("%d", &search);

    first = 0;
    last = n - 1;

    middle = (first + last)/2;

    while(first <= last)
    {
        if(array[middle] < search)
        {
            first = middle + 1;
        }
        else if(array[middle] == search)
        {
            printf("\n%d number is found at location %d", search, (middle + 1));
            break;
        }
        else
        {
            last = middle - 1;
        }

        middle = (first + last)/2;
    }

    return 0;
}
