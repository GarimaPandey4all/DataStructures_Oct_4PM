#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, n, array[10];

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter elements:\n");
    for(i = 0; i < n; i++)
    {
        scanf("%d", &array[i]);
    }

    printf("Unsorted Array:\n");
    for(i = 0; i < n; i++)
    {
        printf("%d  ", array[i]);
    }

    quickSort(array, 0, n - 1); // function calling

    printf("\nSorted Array:\n");
    for(i = 0; i < n; i++)
    {
        printf("%d  ", array[i]);
    }

    return 0;
}

//function definition
void quickSort(int array[10], int first, int last)
{
    int pivot, i, j, temp;

    if(first < last)
    {
        pivot = first;
        i = first;
        j = last;

        while(i < j)
        {
            while(array[pivot] >= array[i] && i < last)
            {
                i++;
            }

            while(array[pivot] < array[j])
            {
                j--;
            }

            if(i < j)
            {
                temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
        }

        //Swapping of pivot value
        temp = array[pivot];
        array[pivot] = array[j];
        array[j] = temp;

        //Left sub-array
        quickSort(array, 0, j - 1); // recursive call

        //Right sub-array
        quickSort(array, j + 1, last);
    }
}
