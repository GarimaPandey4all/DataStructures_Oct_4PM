#include <stdio.h>
#include <stdlib.h>

int main()
{
    int heap[10], i, j, n, root, temp, c;

    printf("Enter number of elements:");
    scanf("%d", &n);

    printf("Enter values:\n");
    for(i = 0; i < n; i++)
    {
        scanf("%d", &heap[i]);
    }

    printf("Unsorted Heap Array:\n");
    for(i = 0; i < n; i++)
    {
        printf("%d  ", heap[i]);
    }

    //Logic for Heap Sort

    /*
        35, 50, 15, 25, 80, 20
        50, 35, 15, 25, 80, 20
        50, 80, 15, 25, 35, 20
        80, 50, 15, 25, 35, 20
        80, 50, 20, 25, 35, 15
    */

    for(i = 1; i < n; i++) // i = 1, 2, 3, 4, 5, 6
    {
        c = i; // 1, 2, 3, 4, 5

        do
        {
            root = (c - 1)/2;// 0, 0, 1, 0, 1, 0, 2, 0

            if(heap[root] < heap[c]) //create max heap array
            {
                temp = heap[root];
                heap[root] = heap[c];
                heap[c] = temp;
            }

            c = root; // 0, 0, 1, 0, 1, 0, 2, 0
        }while(c != 0);
    }

    printf("\nMax Heap Array:\n");
    for(i = 0; i < n; i++)
    {
        printf("%d  ", heap[i]);
    }

    /*
        80, 50, 20, 25, 35, 15
        15, 50, 20, 25, 35, 80
        50, 15, 20, 25, 35, 80
        50, 35, 20, 25, 15, 80
        15, 35, 20, 25, 50, 80
        35, 15, 20, 25, 50, 80
        35, 25, 20, 15, 50, 80
        15, 25, 20, 35, 50, 80
        25, 15, 20, 35, 50, 80
        20, 15, 25, 35, 50, 80
        15, 20, 25, 35, 50, 80
    */

    for(j = n - 1; j >= 0; j--)// j = 5, 4, 3, 2, 1, 0
    {
        //swap maximum element with rightmost leaf element
        temp = heap[0];
        heap[0] = heap[j];
        heap[j] = temp;

        root = 0;

        do
        {
            //left node of element
            c = 2 * root + 1; // 1

            if(heap[c] < heap[c + 1] && c < j - 1)
                c++; // 4

            //rearrange to max heap array
            if(heap[root] < heap[c] && c < j)
            {
                temp = heap[root];
                heap[root] = heap[c];
                heap[c] = temp;
            }

            root = c; // 1, 3
        }while(c < j);
    }

    printf("\nSorted Array:\n");
    for(i = 0; i < n; i++)
    {
        printf("%d  ", heap[i]);
    }

    return 0;
}
